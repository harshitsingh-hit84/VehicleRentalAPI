package com.vehiclerental.dao;

import com.vehiclerental.model.Vehicle;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class VehicleDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // GET ALL VEHICLES
    public List<Vehicle> getAllVehicles() {

        String sql = "SELECT * FROM vehicles";

        return jdbcTemplate.query(sql, (ResultSet rs, int rowNum) -> {

            Vehicle vehicle = new Vehicle();

            vehicle.setId(rs.getInt("id"));
            vehicle.setName(rs.getString("name"));
            vehicle.setBrand(rs.getString("brand"));
            vehicle.setType(rs.getString("type"));
            vehicle.setPricePerDay(rs.getDouble("price_per_day"));
            vehicle.setAvailable(rs.getBoolean("available"));

            return vehicle;
        });
    }

    // GET VEHICLE BY ID
    public Vehicle getVehicleById(int id) {

        String sql = "SELECT * FROM vehicles WHERE id = ?";

        List<Vehicle> vehicles = jdbcTemplate.query(
                sql,
                new Object[]{id},
                (ResultSet rs, int rowNum) -> {

                    Vehicle vehicle = new Vehicle();

                    vehicle.setId(rs.getInt("id"));
                    vehicle.setName(rs.getString("name"));
                    vehicle.setBrand(rs.getString("brand"));
                    vehicle.setType(rs.getString("type"));
                    vehicle.setPricePerDay(rs.getDouble("price_per_day"));
                    vehicle.setAvailable(rs.getBoolean("available"));

                    return vehicle;
                }
        );

        if (vehicles.isEmpty()) {
            return null;
        }

        return vehicles.get(0);
    }

    // ADD VEHICLE
    public int addVehicle(Vehicle vehicle) {

        String sql = "INSERT INTO vehicles "
                + "(name, brand, type, price_per_day, available) "
                + "VALUES (?, ?, ?, ?, ?)";

        return jdbcTemplate.update(
                sql,
                vehicle.getName(),
                vehicle.getBrand(),
                vehicle.getType(),
                vehicle.getPricePerDay(),
                vehicle.isAvailable()
        );
    }

    // UPDATE VEHICLE
    public int updateVehicle(Vehicle vehicle) {

        String sql = "UPDATE vehicles SET "
                + "name = ?, brand = ?, type = ?, "
                + "price_per_day = ?, available = ? "
                + "WHERE id = ?";

        return jdbcTemplate.update(
                sql,
                vehicle.getName(),
                vehicle.getBrand(),
                vehicle.getType(),
                vehicle.getPricePerDay(),
                vehicle.isAvailable(),
                vehicle.getId()
        );
    }

    // DELETE VEHICLE
    public int deleteVehicle(int id) {

        String sql = "DELETE FROM vehicles WHERE id = ?";

        return jdbcTemplate.update(sql, id);
    }
}