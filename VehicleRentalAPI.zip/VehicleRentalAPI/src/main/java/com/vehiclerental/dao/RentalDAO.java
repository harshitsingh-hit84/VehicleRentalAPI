package com.vehiclerental.dao;

import com.vehiclerental.model.Rental;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class RentalDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // ADD RENTAL
    public int addRental(Rental rental) {

        // Check whether vehicle exists and is available
        String availabilitySql =
                "SELECT available FROM vehicles WHERE id = ?";

        List<Boolean> availability = jdbcTemplate.query(
                availabilitySql,
                new Object[]{rental.getVehicleId()},
                (rs, rowNum) -> rs.getBoolean("available")
        );

        // Vehicle does not exist
        if (availability.isEmpty()) {
            return -1;
        }

        // Vehicle is unavailable
        if (!availability.get(0)) {
            return 0;
        }

        // Get vehicle price per day
        String priceSql =
                "SELECT price_per_day FROM vehicles WHERE id = ?";

        Double pricePerDay = jdbcTemplate.queryForObject(
                priceSql,
                Double.class,
                rental.getVehicleId()
        );

        // Calculate total price
        double totalPrice =
                pricePerDay * rental.getRentalDays();

        rental.setTotalPrice(totalPrice);

        // Insert rental
        String sql = "INSERT INTO rentals "
                + "(vehicle_id, customer_name, customer_phone, "
                + "rental_days, total_price, status) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        int result = jdbcTemplate.update(
                sql,
                rental.getVehicleId(),
                rental.getCustomerName(),
                rental.getCustomerPhone(),
                rental.getRentalDays(),
                rental.getTotalPrice(),
                "Booked"
        );

        // Mark vehicle as unavailable
        if (result > 0) {

            String updateVehicle =
                    "UPDATE vehicles SET available = false WHERE id = ?";

            jdbcTemplate.update(
                    updateVehicle,
                    rental.getVehicleId()
            );
        }

        return result;
    }

    // GET ALL RENTALS
    public List<Rental> getAllRentals() {

        String sql = "SELECT * FROM rentals";

        return jdbcTemplate.query(sql, (rs, rowNum) -> {

            Rental rental = new Rental();

            rental.setId(rs.getInt("id"));
            rental.setVehicleId(rs.getInt("vehicle_id"));
            rental.setCustomerName(rs.getString("customer_name"));
            rental.setCustomerPhone(rs.getString("customer_phone"));
            rental.setRentalDays(rs.getInt("rental_days"));
            rental.setTotalPrice(rs.getDouble("total_price"));
            rental.setStatus(rs.getString("status"));

            return rental;
        });
    }

    // GET RENTAL BY ID
    public Rental getRentalById(int id) {

        String sql =
                "SELECT * FROM rentals WHERE id = ?";

        List<Rental> rentals = jdbcTemplate.query(
                sql,
                new Object[]{id},
                (rs, rowNum) -> {

                    Rental rental = new Rental();

                    rental.setId(rs.getInt("id"));
                    rental.setVehicleId(
                            rs.getInt("vehicle_id"));
                    rental.setCustomerName(
                            rs.getString("customer_name"));
                    rental.setCustomerPhone(
                            rs.getString("customer_phone"));
                    rental.setRentalDays(
                            rs.getInt("rental_days"));
                    rental.setTotalPrice(
                            rs.getDouble("total_price"));
                    rental.setStatus(
                            rs.getString("status"));

                    return rental;
                }
        );

        if (rentals.isEmpty()) {
            return null;
        }

        return rentals.get(0);
    }

    // CANCEL RENTAL
    public int cancelRental(int rentalId) {

        // Find the vehicle belonging to this rental
        String vehicleSql =
                "SELECT vehicle_id FROM rentals WHERE id = ?";

        List<Integer> vehicleIds = jdbcTemplate.query(
                vehicleSql,
                new Object[]{rentalId},
                (rs, rowNum) -> rs.getInt("vehicle_id")
        );

        // Rental not found
        if (vehicleIds.isEmpty()) {
            return -1;
        }

        int vehicleId = vehicleIds.get(0);

        // Check current rental status
        String statusSql =
                "SELECT status FROM rentals WHERE id = ?";

        String status = jdbcTemplate.queryForObject(
                statusSql,
                String.class,
                rentalId
        );

        // Already cancelled
        if ("Cancelled".equalsIgnoreCase(status)) {
            return 0;
        }

        // Cancel rental
        String updateRental =
                "UPDATE rentals SET status = 'Cancelled' "
                + "WHERE id = ?";

        int result = jdbcTemplate.update(
                updateRental,
                rentalId
        );

        // Make vehicle available again
        if (result > 0) {

            String updateVehicle =
                    "UPDATE vehicles SET available = true "
                    + "WHERE id = ?";

            jdbcTemplate.update(
                    updateVehicle,
                    vehicleId
            );
        }

        return result;
    }
}