package com.vehiclerental.model;

public class Rental {

    private int id;
    private int vehicleId;
    private String customerName;
    private String customerPhone;
    private int rentalDays;
    private double totalPrice;
    private String status;

    public Rental() {
    }

    public Rental(int id, int vehicleId, String customerName,
                  String customerPhone, int rentalDays,
                  double totalPrice, String status) {
        this.id = id;
        this.vehicleId = vehicleId;
        this.customerName = customerName;
        this.customerPhone = customerPhone;
        this.rentalDays = rentalDays;
        this.totalPrice = totalPrice;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public int getRentalDays() {
        return rentalDays;
    }

    public void setRentalDays(int rentalDays) {
        this.rentalDays = rentalDays;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}