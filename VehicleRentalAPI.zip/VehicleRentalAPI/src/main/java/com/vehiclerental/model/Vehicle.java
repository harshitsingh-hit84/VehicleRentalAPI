package com.vehiclerental.model;

public class Vehicle {

    private int id;
    private String name;
    private String brand;
    private String type;
    private double pricePerDay;
    private boolean available;

    public Vehicle() {
    }

    public Vehicle(int id, String name, String brand,
                   String type, double pricePerDay,
                   boolean available) {
        this.id = id;
        this.name = name;
        this.brand = brand;
        this.type = type;
        this.pricePerDay = pricePerDay;
        this.available = available;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getPricePerDay() {
        return pricePerDay;
    }

    public void setPricePerDay(double pricePerDay) {
        this.pricePerDay = pricePerDay;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}