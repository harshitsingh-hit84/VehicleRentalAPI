package com.vehiclerental.controller;

import com.vehiclerental.dao.RentalDAO;
import com.vehiclerental.model.Rental;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/rentals")
public class RentalController {

    @Autowired
    private RentalDAO rentalDAO;

    // CREATE RENTAL
    @PostMapping
    public ResponseEntity<String> addRental(
            @RequestBody Rental rental) {

        int result = rentalDAO.addRental(rental);

        if (result == -1) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("Vehicle not found");
        }

        if (result == 0) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body("Vehicle is currently unavailable");
        }

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body("Rental booked successfully. Total price: Rs. "
                        + rental.getTotalPrice());
    }

    // GET ALL RENTALS
    @GetMapping
    public ResponseEntity<List<Rental>> getAllRentals() {

        return ResponseEntity.ok(
                rentalDAO.getAllRentals()
        );
    }

    // GET RENTAL BY ID
    @GetMapping("/{id}")
    public ResponseEntity<Rental> getRentalById(
            @PathVariable int id) {

        Rental rental = rentalDAO.getRentalById(id);

        if (rental == null) {
            return ResponseEntity
                    .notFound()
                    .build();
        }

        return ResponseEntity.ok(rental);
    }

    // CANCEL RENTAL
    @PutMapping("/{id}/cancel")
    public ResponseEntity<String> cancelRental(
            @PathVariable int id) {

        int result = rentalDAO.cancelRental(id);

        if (result == -1) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("Rental not found");
        }

        if (result == 0) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body("Rental is already cancelled");
        }

        return ResponseEntity.ok(
                "Rental cancelled successfully. Vehicle is now available."
        );
    }
}