package com.vehiclerental.controller;

import com.vehiclerental.dao.VehicleDAO;
import com.vehiclerental.model.Vehicle;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/vehicles")
public class VehicleController {

    @Autowired
    private VehicleDAO vehicleDAO;

    // GET ALL VEHICLES
    @GetMapping
    public ResponseEntity<List<Vehicle>> getAllVehicles() {
        return ResponseEntity.ok(vehicleDAO.getAllVehicles());
    }

    // GET VEHICLE BY ID
    @GetMapping("/{id}")
    public ResponseEntity<Vehicle> getVehicleById(@PathVariable int id) {

        Vehicle vehicle = vehicleDAO.getVehicleById(id);

        if (vehicle == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(vehicle);
    }

    // ADD VEHICLE
    @PostMapping
    public ResponseEntity<String> addVehicle(@RequestBody Vehicle vehicle) {

        vehicleDAO.addVehicle(vehicle);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body("Vehicle added successfully");
    }

    // UPDATE VEHICLE
    @PutMapping("/{id}")
    public ResponseEntity<String> updateVehicle(
            @PathVariable int id,
            @RequestBody Vehicle vehicle) {

        vehicle.setId(id);

        int result = vehicleDAO.updateVehicle(vehicle);

        if (result == 0) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok("Vehicle updated successfully");
    }

    // DELETE VEHICLE
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteVehicle(@PathVariable int id) {

        int result = vehicleDAO.deleteVehicle(id);

        if (result == 0) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok("Vehicle deleted successfully");
    }
}